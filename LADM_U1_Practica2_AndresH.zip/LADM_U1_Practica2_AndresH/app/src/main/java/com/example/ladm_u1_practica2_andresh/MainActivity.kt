package com.example.ladm_u1_practica2_andresh

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            if (radioButton.isChecked){
                    guardarEnInterna()
            } else if(radioButton2.isChecked){
                    guardarEnSD()
            } else{
                mensaje("Por favor, seleccione una opción para guardar")
            }
        }

        button2.setOnClickListener {
            if (radioButton.isChecked){
                leerEnInterna()
            } else if(radioButton2.isChecked){
                leerEnSD()
            } else{
                mensaje("Por favor, seleccione una opción para leer")
            }
        }

        radioButton2.setOnClickListener {
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_DENIED){
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE),0)
            }
        }
    }

    fun guardarEnInterna(){
        if(editText2.text.isEmpty()) {
            mensaje("Por favor asigne un nombre")

        } else { try {
            var flujoSalida = OutputStreamWriter(
                openFileOutput(
                    editText2.text.toString() + ".txt",
                    Context.MODE_PRIVATE
                )
            )

            var data = editText.text.toString()

            flujoSalida.write(data)
            flujoSalida.flush()
            flujoSalida.close()

            mensaje("El arcihvo se ha guardado")
            limpiarCampos()

        } catch (error: IOException) {
            mensaje(error.message.toString())
        }}
    }

    fun guardarEnSD(){
        if(noSD()){
            mensaje("No hay memoria externa")
            return@guardarEnSD
        }
        if(editText2.text.isEmpty()){ mensaje("Por favor, asigne un nombre")
        }else {
            try {
                var rutaSD = Environment.getExternalStorageDirectory()
                var datosrAchivo = File(rutaSD.absolutePath, editText2.text.toString() + ".txt")
                var flujoSalida = OutputStreamWriter(FileOutputStream(datosrAchivo))

                var data = editText.text.toString()

                flujoSalida.write(data)
                flujoSalida.flush()
                flujoSalida.close()

                mensaje("El archivo se ha guardado")
                limpiarCampos()

            } catch (error: IOException) {
                mensaje(error.message.toString())
            }
        }
    }

    fun leerEnInterna(){
        if(editText2.text.isEmpty()){mensaje("Por favor, indique el nombre del archivo")
        }else {
            try {

                var flujoEntrada =
                    BufferedReader(InputStreamReader(openFileInput(editText2.text.toString() + ".txt")))

                var data = flujoEntrada.readLine()

                editText.setText(data.toString())

            } catch (error: IOException) {
                mensaje(error.message.toString())
            }
        }
    }

    fun leerEnSD(){
        if(noSD()){
            mensaje("No hay memoria SD")
            return@leerEnSD
        }

        if(editText2.text.isEmpty()){mensaje("Por favor, indique el nombre")
        } else {
            try {
                var rutaSD = Environment.getExternalStorageDirectory()
                var datosrAchivo = File(rutaSD.absolutePath, editText2.text.toString() + ".txt")

                var flujoEntrada = BufferedReader(InputStreamReader(FileInputStream(datosrAchivo)))

                var data = flujoEntrada.readLine()

                editText.setText(data.toString())

            } catch (error: IOException) {
                mensaje(error.message.toString())
            }
        }
    }

    fun mensaje(m:String){
        AlertDialog.Builder(this)
            .setTitle("Atención")
            .setMessage(m)
            .setPositiveButton("Aceptar"){d,i->}
            .show()
    }

    fun limpiarCampos(){
        editText.setText("")
        editText2.setText("")
    }

    fun noSD():Boolean{
        var estado = Environment.getExternalStorageState()
        if(estado!= Environment.MEDIA_MOUNTED)
            return true

        return false
    }
}
